# Yoga Awareness & Practice — CSP Website

Responsive, green nature-inspired website for Bandi Rohini's Community Service Project.

## Files
- `index.html` — all sections and the eight-week activity outline
- `style.css` — responsive styling
- `script.js` — mobile navigation
- `images/` — add the banner and your project photos

## Publish with GitHub Pages
1. Upload the contents of this folder to the root of your GitHub repository.
2. Open **Settings → Pages**.
3. Choose **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.

The eight-week activity descriptions are a framework. Edit them to reflect your actual work and dates. Do not present planned activities as completed activities.
